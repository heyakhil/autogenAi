import classes from "./App.module.css";
import { useDisclosure } from "@mantine/hooks";
import React, { useState } from "react";
import {
  Grid,
  Paper,
  Text,
  Burger,
  Button,
  ActionIcon,
  Container,
} from "@mantine/core";
import { MdMenu, MdClose } from "react-icons/md";

import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  // const items = links.map((link, index) => (
  //   <div style={{ display: "flex" }}>
  //     <a
  //       key={link.label}
  //       href={link.link}
  //       className={classes.link}
  //       data-active={active === link.link || undefined}
  //       onClick={(event) => {
  //         event.preventDefault();
  //         setActive(link.link);
  //       }}
  //     >
  //       {link.label}
  //     </a>
  //     {links.length - 1 !== index && <div className={classes.seprator} />}
  //   </div>
  // ));

  return (
    <>
      <div className={classes.bannerarea}>
        <Container mx={200} className={classes.container}>
          <div className="row gap-3">
            <div className="col-lg-7 col-md-7 col-sm-12">
              <h1>
                Write high-quality, winning bids & proposals faster than ever.
              </h1>
              <hr />
              <p>
                Harness the power of augmented intelligence to write
                high-quality bids, proposals and tenders.
              </p>
              <p>
                Use AutogenAI to create exceptional bids in minutes, not days.
              </p>

              <button className="btn btn-sm btn-info">Book a Demo</button>
            </div>
            <div className="col-lg-4 col-md-4 col-sm-12">
              <iframe
                width="100%"
                height="315"
                src="https://www.youtube.com/embed/3SyHScC96Ws?si=tO-ThHdaAwasBGOx"
                title="YouTube video player"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              ></iframe>
            </div>
          </div>
        </Container>
      </div>

      <div className="trust-sec text-center">
        <div className="container">
          <h2>Trusted by</h2>
          <hr className="center" />
          <div className="row"></div>
        </div>
      </div>

      <div className="bid-write">
        <div className="container">
          <div className="row">
            <div className="col-md-8">
              <h2 className="text-left">A new way of bid writing</h2>
              <hr />
              <p className="max-w-text">
                Bid teams spend 80% of their time in the drafting stage with
                little scope to edit, enhance and elevate the quality of their
                work. Our world className engineers have dedicated over 50,000
                hours to building software that allows you to spend more time on
                the activities that get you to a winning bid.
              </p>
            </div>
            <div className="col-md-4">
              <div className="grid">
                <div className="box">
                  <img src="images/up-circle.png" alt="" />
                  <h3>70% Increase</h3>
                  <p>In Drafting Speed</p>
                </div>
                <div className="box">
                  <img src="images/up-circle.png" alt="" />
                  <h3>70% Increase</h3>
                  <p>In Drafting Speed</p>
                </div>
                <div className="box">
                  <img src="images/up-circle.png" alt="" />
                  <h3>70% Increase</h3>
                  <p>In Drafting Speed</p>
                </div>
                <div className="box">
                  <img src="images/up-circle.png" alt="" />
                  <h3>70% Increase</h3>
                  <p>In Drafting Speed</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
